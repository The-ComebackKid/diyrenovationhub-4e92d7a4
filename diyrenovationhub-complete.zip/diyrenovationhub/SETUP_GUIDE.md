# DIY Renovation Hub — Deployment & Integration Guide
## Your Complete Setup Playbook

---

## WHAT'S IN THIS PACKAGE

```
diyrenovationhub/
├── index.html                        ← Full 4-page website
├── success.html                      ← Post-purchase confirmation page
├── netlify.toml                      ← Netlify config (security headers, routing)
├── package.json                      ← Dependencies (Stripe SDK)
├── netlify/
│   └── functions/
│       ├── create-checkout.js        ← Stripe checkout session creator
│       └── subscribe.js              ← Klaviyo email list subscriber
└── SETUP_GUIDE.md                    ← This file
```

---

## STEP 1 — DEPLOY TO NETLIFY (Free)

### 1a. Create your Netlify account
→ Go to https://netlify.com → Sign up free

### 1b. Deploy the site
**Option A — Drag & Drop (fastest):**
1. Log into Netlify
2. Go to "Sites" → drag the entire `diyrenovationhub` folder onto the drop zone
3. Site goes live instantly at a random netlify.app URL

**Option B — GitHub (recommended for ongoing updates):**
1. Create a free GitHub account at github.com
2. Create a new repository called `diyrenovationhub`
3. Upload all files in the `diyrenovationhub` folder
4. In Netlify → "Add new site" → "Import from Git" → Connect GitHub → Select repo
5. Build settings: leave defaults blank (no build command needed)
6. Deploy

### 1c. Connect your custom domain (diyrenovationhub.org)
1. In Netlify: Site Settings → Domain Management → Add custom domain
2. Enter: `diyrenovationhub.org`
3. Netlify will show you DNS records (usually 2 nameserver entries)
4. Log into wherever your domain is registered (GoDaddy, Namecheap, etc.)
5. Find "Nameservers" → Replace existing nameservers with Netlify's
6. Wait 10–30 minutes → your site is live at diyrenovationhub.org
7. Netlify auto-provisions SSL (HTTPS) — free, automatic

---

## STEP 2 — STRIPE SETUP

### 2a. Create/access your Stripe account
→ https://dashboard.stripe.com

### 2b. Get your API keys
1. Stripe Dashboard → Developers → API Keys
2. Copy your **Secret Key** (starts with `sk_live_...`)
   - ⚠️ NEVER share this key. NEVER put it in your HTML file.
   - Use `sk_test_...` first to test, then switch to `sk_live_...` when ready

### 2c. Add environment variable to Netlify
1. Netlify Dashboard → Your Site → Site Configuration → Environment Variables
2. Click "Add variable"
3. Key: `STRIPE_SECRET_KEY`
4. Value: `sk_live_YOUR_ACTUAL_KEY_HERE`
5. Click Save
6. Also add: `SITE_URL` = `https://diyrenovationhub.org`

### 2d. Test a purchase
1. Use test key `sk_test_...` first
2. Use Stripe test card: `4242 4242 4242 4242` / any future date / any CVC
3. Confirm the success page appears
4. Switch to live key when ready

### 2e. Course prices (update in create-checkout.js if needed)
| Course ID    | Name                                  | Price  |
|--------------|---------------------------------------|--------|
| masterclass  | Complete Home Renovation Masterclass  | $197   |
| electrical   | Residential Wiring Decoded            | $97    |
| plumbing     | Rough-In to Finish Plumbing           | $97    |
| structural   | Structural & Framing Fundamentals     | $97    |
| tile         | Tile, Stone & Waterproofing           | $97    |
| investor     | Renovation for Real Estate Investors  | $147   |

---

## STEP 3 — KLAVIYO SETUP

### 3a. Create/access your Klaviyo account
→ https://klaviyo.com

### 3b. Get your Private API Key
1. Klaviyo → Settings (bottom left) → API Keys
2. Create a **Private API Key** with "Full Access" or at minimum:
   - Profiles: Read/Write
   - Lists: Read/Write
3. Copy the key (starts with `pk_...`)

### 3c. Create your email list
1. Klaviyo → Lists & Segments → Create List
2. Name it: "DIY Renovation Hub — Main List"
3. After creation, click the list → the URL will contain the List ID
   Example: `https://www.klaviyo.com/list/XXXXXX/...` → your List ID is `XXXXXX`

### 3d. Add environment variables to Netlify
1. Netlify → Environment Variables → Add:
   - Key: `KLAVIYO_PRIVATE_KEY` / Value: `pk_YOUR_KEY_HERE`
   - Key: `KLAVIYO_LIST_ID` / Value: `YOUR_LIST_ID`

### 3e. Create your welcome email in Klaviyo
1. Klaviyo → Flows → Create Flow → "List Triggered"
2. Trigger: when someone joins your main list
3. Add email: Subject: "Your Free Renovation Guide is Inside"
4. Body: Include your free guide PDF as a download link
5. This fires automatically every time someone signs up

---

## STEP 4 — DELIVER PURCHASED COURSES

### Option A — Simple (Recommended to Start)
1. Upload your course PDFs/videos to Google Drive or Dropbox
2. Create shareable links for each course
3. In Stripe Dashboard → Products → Each product → Add metadata:
   - Key: `download_url` / Value: your Google Drive link
4. Set up a Stripe webhook or simply email buyers manually from Stripe notifications

### Option B — Automated Delivery
1. Use **Gumroad** or **Podia** as a content delivery layer
2. Set Stripe to redirect to their platform post-purchase
3. They handle the file delivery and member access automatically

### Option C — Full Automation (Advanced)
1. Create a Netlify function `deliver-course.js`
2. Listen to Stripe webhooks for `checkout.session.completed`
3. Send email via Klaviyo with the download link
4. (I can build this for you as the next step)

---

## STEP 5 — GO LIVE CHECKLIST

Before launching, confirm:

- [ ] Site live at diyrenovationhub.org with HTTPS
- [ ] All 4 pages load correctly (Home, Courses, Blog, Contact)
- [ ] Test Stripe checkout with test card `4242 4242 4242 4242`
- [ ] Success page loads after test purchase
- [ ] Email signup adds contact to Klaviyo list
- [ ] Welcome email sends automatically in Klaviyo
- [ ] Stripe switched to LIVE keys
- [ ] info@diyrenovationhub.org email is working (set up via Google Workspace or Zoho)

---

## MONTHLY COSTS (After Setup)

| Service         | Cost              | Notes                              |
|-----------------|-------------------|------------------------------------|
| Netlify         | FREE              | Free tier covers this site fully   |
| Domain          | ~$12/yr           | Already have this                  |
| Stripe          | 2.9% + 30¢/sale   | No monthly fee. Pay per transaction|
| Klaviyo         | FREE up to 250    | Paid starts ~$20/mo at 251+        |
| Google Workspace| $6/mo (optional)  | For info@ email address            |

**Total to start: $0–$6/month**

---

## FUTURE PHASES (Phase 2 & 3)

### Phase 2 — Automate Everything
- Stripe webhook → auto-email course files via Klaviyo
- Abandoned cart email sequence
- Post-purchase upsell flow (bought electrical? offer plumbing)

### Phase 3 — Scale
- Member portal (Memberstack or Outseta)
- Video hosting (Vimeo or Wistia)
- Affiliate program (Rewardful)
- Blog CMS (Netlify CMS or Sanity.io — free tiers available)
- SEO optimization + Google Search Console setup

---

## SUPPORT

Any issues with setup, next-phase builds, or integrations:
→ Bring them back to your Claude session and we execute immediately.

---
*Built for DIY Renovation Hub — diyrenovationhub.org*
